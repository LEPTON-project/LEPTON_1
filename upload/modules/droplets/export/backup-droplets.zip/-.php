//:Adds a shy-entitie.
//:Adds a shy-entitie. Used e.g. by a CK-Editor-Plugin.
return "&shy;";